import React from "react";

  export default class Footer extends React.Component {
    render(){
  return (
    <div>
      <footer>

        <div>© 2023 NAMAN KHANDELWAL
          {/* <a href="/"> MDBootstrap.com</a> */}
        </div>

      </footer>
    </div>
  )
}}

