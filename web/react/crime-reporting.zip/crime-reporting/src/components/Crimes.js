import * as firebase from 'firebase';
import React, { Component } from 'react';
import { Search } from '../store/action/auth'
import { connect } from 'react-redux'


class Crimes extends Component {
  constructor() {
    super();

    this.state = {
      arr: []
    }
    this.onSearch = this.onSearch.bind(this)
  }


  onSearch(e) {
    let _self = this;
    e.preventDefault()
    let ref = firebase.database().ref().child('/crimeList');
    _self.arr = [];

    console.log(this.refs.selectedCity.value)
    ref.orderByChild('city').equalTo(this.refs.selectedCity.value).once('value', function (snapshot) {



      snapshot.forEach(childSnapshot => {

        _self.arr.push(childSnapshot.val())
        console.log("arr", _self.arr)

      })
      _self.props.serachCrimes(_self.arr)
      _self.setState({
        arr: _self.props.storeReducer.crimes

      })
    });
  }

  render() {
    return (
      <div >

        <div className="container my-2 py-3">
          <div className="row">
            <div className="col-12 mb-5">
              <h2 className="display-7 fw-bold text-center">Crime List</h2>
              <hr/>
             
              <div className="modal-header">
               
                <div className="modal-body ">     
                  <form  onSubmit={this.onSearch} className="form-inline justify-content-center mt-0 pt-0">

                    <div className="form-group mx-sm-3  mb-2 mr-2 ">
                      <select name="city"
                        className="btn btn-outline-dark mb-2"
                        id="dropdownMenuButton"
                        ref="selectedCity"
                        required
                      >

                        <option className="dropdown-item-light">City   </option>
                        <option className="dropdown-item-light" value="Alwar">Alwar</option>
                        <option className="dropdown-item-light" value="Udaipur">Udaipur</option>
                        <option className="dropdown-item-light" value="Jaipur">Jaipur</option>
                        <option className="dropdown-item-light" value="Jodhpur">Jodhpur</option>
                        <option className="dropdown-item-light" value="Bikaner">Bikaner</option>
                        <option className="dropdown-item-light" value="Ajmar">Ajmar</option>
                        <option className="dropdown-item-light" value="Kota">Kota</option>
                        <option className="dropdown-item-light" value="Pushkar">Pushkar</option>
                        <option className="dropdown-item-light" value="Bhiwadi">Bhiwadi</option>
                        <option className="dropdown-item-light" value="Dausa">Dausa</option>
                      </select>
                     
                    </div>
                    <button type="submit" label="Sign up" onClick={this.onSearch} className="btn btn-outline-primary w-25 mb-3" primary={true}>Find</button>

                  </form>


                </div>
              </div>
              
            </div>
          </div>
          <div className="row justify-content-left">
            {console.log("this.state.arr", this.state.arr)}
            {this.state.arr.map((c, i) => {
              return (

                <div className=" col-md-4 mb-4">
                  <div className="card h-100 text-left p-0" >
                    <div className="card-body">
                      <p className="card-text fw-bold ">Name: {c.informerName}</p>
                      <p className="card-title mb-0">City: {c.city}</p>
                      <p className="card-title mb-0">Crime: {c.crime}</p>
                      <p className="card-title mb-0">Informer Mobile: {c.informerMobile}</p>
                    </div>
                  </div>
                </div>

              )
            })

            }
          </div>
        </div>

      </div>
    );
  }
}

const mapStateToProps = (state) => {
  console.log(state.CrimeReducer)
  return {
    storeReducer: state.CrimeReducer
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    serachCrimes: (data) => {
      console.log(data)
      dispatch(Search(data))
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Crimes);

