import * as firebase from 'firebase';
import React, { Component } from 'react';
import { Search } from '../store/action/auth'
import { connect } from 'react-redux'

class ComplaintsList extends Component {
    constructor() {
        super();

        this.state = {
            
            arr: []
        }
    }




    componentWillMount() {
        let _self = this;

        let ref = firebase.database().ref().child('/complainList');
        _self.arr = [];

        ref.once('value', function (snapshot) {

            snapshot.forEach(childSnapshot => {

                _self.arr.push(childSnapshot.val())
                console.log("arr", _self.arr)
            })
            _self.props.serachComplaint(_self.arr)
            _self.setState({
                arr: _self.props.storeReducer.complaint

            })
        });
    }

    render() {
        return (
            <div >
                <div className="container my-2 py-3">
                    <div className="row">
                        <div className="col-12 mb-5">
                            <h2 className="display-7 fw-bold text-center">Complaint List</h2>
                            <hr />
                        </div>
                    </div>
                    <div className="row justify-content-left">
                        {console.log("this.state.arr", this.state.arr)}
                        {this.state.arr.map((co, i) => {
                            return (

                                <div className=" col-md-4 mb-4">
                                    <div className="card h-100 text-left p-0" >
                                        <div className="card-body">
                                            <p className="card-text fw-bold ">Name: {co.informerName}</p>
                                            <p className="card-title mb-0">City: {co.city}</p>
                                            <p className="card-title mb-0">Complaint: {co.complaint}</p>
                                            <p className="card-title mb-0">Informer Mobile: {co.informerMobile}</p>
                                        </div>
                                    </div>
                                </div>

                            )
                        })

                        }
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    console.log(state.ComplaintReducer)
    return {
        storeReducer: state.ComplaintReducer
    }
}
const mapDispatchToProps = (dispatch) => {
    return {
        serachComplaint: (data) => {
            console.log(data)
            dispatch(Search(data))
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ComplaintsList);

