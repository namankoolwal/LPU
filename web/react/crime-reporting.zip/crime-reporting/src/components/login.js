import React, { Component } from 'react'
import { signIn } from '../store/action/auth'
import { connect } from 'react-redux'
import { DBfirebase } from '../database/DBfirebase'
import { Link } from "react-router"

class Login extends Component {
    constructor() {
        super();
        this.state = {
            email: '',
            password: ''
        }
        this.signin = this.signin.bind(this);
        this.inputHandler = this.inputHandler.bind(this);
    }
    inputHandler(e) {
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    signin(e) {
        e.preventDefault()
        DBfirebase.customLogin(this.state)
            .then((user) => {
                this.props.signInUser(user)
                localStorage.setItem('currentUser', user.uid);
                this.context.router.push({
                    pathname: '/home/missingpeopleparent',
                    // state: this.props.user
                })
            })
            .catch((error) => alert(error.message))
        console.log(this.props)
    }
    render() {
        return (
            <div >
                <SigninComponent _inputHandler={this.inputHandler} _submit={this.signin} />
            </div>
        )
    }
}

Login.contextTypes = {
    router: React.PropTypes.object.isRequired
}

const mapStateToProps = (state) => {
    return {
        authReducer: state
    }
}
const mapDispatchToProps = (dispatch) => {
    return {
        signInUser: (data) => {
            dispatch(signIn(data))
        }
    }
}



class SigninComponent extends React.Component {

   
    render() {
        return (


            <div
                className="px-4 my-4 bg-light rounded-3 py-2"
                id="loginModal"
                tabIndex="-1"
                aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div className="modal-dialog">
                    <div className="modal-content">
                        <center> <div className="modal-header">
                            <h3 className="modal-title " id="exampleModalLabel">
                                Login
                            </h3>
                            
                        </div></center>
                        <div className="modal-body">


                            <form onSubmit={this.props._submit}>
                                <div className="mb-3">
                                    <label htmlFor="exampleInputEmail1" className="form-label">
                                        Email address
                                    </label>

                                    <input
                                        type="email"
                                        name="email"
                                        className="form-control"
                                        id="exampleInputEmail1"
                                        placeholder='Email'
                                        onChange={this.props._inputHandler}
                                        required
                                    />
                                    <div id="emailHelp" className="form-text">
                                        We'll never share your email with anyone else.
                                    </div>

                                </div>
                                <div className="mb-3">
                                    <label htmlFor="exampleInputPassword1" className="form-label">
                                        Password
                                    </label>
                                    <input

                                        className="form-control"
                                        id="exampleInputPassword1"
                                        type="password"
                                        placeholder="Password"
                                        name="password"
                                        onChange={this.props._inputHandler}
                                        required
                                    />
                                </div>
                                
                            <center>
                                <button type="submit" className="btn btn-outline-primary mt-3 w-50" label="Sign in"  primary={true}>Sign in</button>
                                </center>
                                <Link to="/signup">

                                    <center> <div id="emailHelp" className="form-text-primary mt-3">
                                        Or Create Account
                                    </div> </center> </Link>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        )
    }
}
SigninComponent.PropTypes = {
    _inputHandler: React.PropTypes.func.isRequired,
    _submit: React.PropTypes.func.isRequired

}


export default connect(mapStateToProps, mapDispatchToProps)(Login);
