import React from "react"
import { Link, browserHistory } from "react-router"
import * as firebase from "firebase"


export default class HeaderInner extends React.Component {

    logoutBtn() {
        firebase.auth().signOut();
        browserHistory.push("/login");
        // alert("log out succesfully")
    }

    render() {
        return (
           

            <div className="navbarpg ">
            <nav className="navbar navbar-expand-lg navbar-dark bg-dark py-3 shadow-sm sticky-top">
              {/* <div className="container-fluid"> */}
                <Link className="navbar-brand fw-bold fs-4 mx-3" to="/home/missingpeopleparent">
                  <i class="fa fa-book" aria-hidden="true"></i> Reporting App
                </Link>
                <button
                  className="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarSupportedContent1"
                  aria-controls="navbarSupportedContent1"
                  aria-expanded="false"
                  aria-label="Toggle navigation">
      
                  <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarSupportedContent1">
                  
                  
                  <ul className="navbar-nav mx-auto mb-2 mb-lg-0">
                  </ul>


                  <div className="buttons">
                    <ul className="navbar-nav mx-5 mb-2 mb-lg-0">
                    
                      <Link to="/home/missingpeopleparent" className="btn btn-outline-light ms-2" primary={false}>
                      <i className="fa fa-remove me-1"></i> Missing</Link>

                      <Link to="/home/crimeparent" className="btn btn-outline-light ms-2" primary={false}>
                      <i className="fa fa-chain me-1"></i> Crimes</Link>
                     
                      <Link to="/home/complaintsparent/complaintslist" className="btn btn-outline-light ms-2" primary={false}>
                      <i className="fa fa-bullhorn me-1"></i> Complaint</Link>
      
      
                      
                    <Link to='/' className="btn btn-outline-light ms-2" onClick={this.logoutBtn.bind(this)}  primary={false}>
                      <i className="fa fa-sign-out me-1 "></i> Logout</Link>
                     
                    </ul>
                  </div>
      
      
                </div>
              {/* </div> */}
            </nav>
            {this.props.children}
          </div>
        )
    }
}

