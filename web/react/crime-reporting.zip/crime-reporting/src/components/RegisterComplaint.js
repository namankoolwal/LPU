import React, { Component } from 'react'
import { Link, browserHistory } from 'react-router';
import { DBfirebase } from '../database/DBfirebase'

class RegisterComplaint extends Component {
    constructor() {
        super();
        this.state = {
            informerName: '',
            informerMobile: '',
            city: '',
            complaint: ''

        }
        this.submit = this.submit.bind(this);
        this.inputHandler = this.inputHandler.bind(this);
    }
    inputHandler(e) {
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    submit(e) {
        e.preventDefault();
        let multipath = {};
        let complaint = {
            informerName: this.state.informerName,
            informerMobile: this.state.informerMobile,
            city: this.state.city,
            complaint: this.state.complaint,
        }
        console.log(complaint)
        DBfirebase.refComplain.push(complaint);
        browserHistory.push('/home/complaintsparent/complaintslist')

    }
    render() {
        return (
            <div ><center>
                <ComplaintForm signUpState={this.state} _inputHandler={this.inputHandler} _submit={this.submit} />
            </center>
            </div>
        );
    }
}

RegisterComplaint.contextTypes = {
    router: React.PropTypes.object.isRequired
}


class ComplaintForm extends React.Component {

    render() {

        return (

            <div
             className="px-0 my-0 bg-light rounded-5 py-0"
            id="loginModal"
                tabIndex="-1"
                aria-labelledby="exampleModalLabel"
                aria-hidden="true">
            <div  >
                <div className="modal-content">
                   
                    <div className="modal-header justify-content-center">
                          <h3 className="display-7 fw-bold text-center m-3 " id="exampleModalLabel">
                           Register A Complaint
                        </h3>
                      
                    </div>

                    

                    <div className="modal-body">    
                               
                <form className="form justify-content-center mx-sm-3 m-3" onSubmit={this.props._submit} >

                    <div className="form-row justify-content-center mt-4 ">
                        <div className="col-md-4 mb-3">

                            <input type="text" className="form-control" id="validationDefault03" placeholder="Full Name"
                                name="informerName" value={this.props.signUpState.informerName} onChange={this.props._inputHandler}
                                required />
                        </div>
                        <div className="col-md-2 mb-3">

                            <input type="text" className="form-control" id="validationDefault04" placeholder="Mobile"
                                name="informerMobile"
                                value={this.props.signUpState.informerMobile}
                                onChange={this.props._inputHandler}
                                required />
                        </div>
                    </div>


                    <div className="form-row justify-content-center my-2 ">
                        <div className="col-md-6 mb-3">
                            <textarea className="form-control mb-2 mr-sm-2 h-100" id="validationDefault01" placeholder="Complaint" required
                                name="complaint" value={this.props.signUpState.complaint}
                                onChange={this.props._inputHandler}
                            />
                        </div>
                    </div>

                    <select name="city"
                        className="btn btn-outline-dark col-md-2 mb-2 mr-2"
                        id="dropdownMenuButton"
                        ref="selectedCity"
                        value={this.props.signUpState.city}
                        onChange={this.props._inputHandler}
                        required
                    >

                        <option className="dropdown-item-light">City   </option>
                        <option className="dropdown-item-light" value="Alwar">Alwar</option>
                        <option className="dropdown-item-light" value="Udaipur">Udaipur</option>
                        <option className="dropdown-item-light" value="Jaipur">Jaipur</option>
                        <option className="dropdown-item-light" value="Jodhpur">Jodhpur</option>
                        <option className="dropdown-item-light" value="Bikaner">Bikaner</option>
                        <option className="dropdown-item-light" value="Ajmar">Ajmar</option>
                        <option className="dropdown-item-light" value="Kota">Kota</option>
                        <option className="dropdown-item-light" value="Pushkar">Pushkar</option>
                        <option className="dropdown-item-light" value="Bhiwadi">Bhiwadi</option>
                        <option className="dropdown-item-light" value="Dausa">Dausa</option>
                    </select>
                  

                        <div className="form-row justify-content-center my-4">

                    <button label="Register a Complaint" className="btn btn-primary col-md-3 mb-3 " type="submit" primary={false} secondary={true} >Register Complaint</button>
                        </div>
                </form>
                </div> 
               
                </div>
                </div>

            </div>

            
        )
    }
}


export default RegisterComplaint;
