import * as firebase from 'firebase';
import React, { Component } from 'react';
import { Search } from '../store/action/auth'
import { connect } from 'react-redux'

class MissingPeopleList extends Component {
  constructor() {
    super();

    this.state = {
      arr: []
    }
    this.onSearch = this.onSearch.bind(this)
  }

  onSearch(e) {
    let _self = this;
    e.preventDefault()
    let ref = firebase.database().ref().child('/missingPeople');
    _self.arr = [];
    console.log(this.refs.selectedCity.value)
    ref.orderByChild('city').equalTo(this.refs.selectedCity.value).once('value', function (snapshot) {



      snapshot.forEach(childSnapshot => {

        _self.arr.push(childSnapshot.val())
        console.log("arr", _self.arr)

      })
      _self.props.serachPeople(_self.arr)
      _self.setState({
        arr: _self.props.storeReducer.missingPeople

      })
    });
  }

  render() {
    return (
         <div >

        <div className="container my-2 py-3">
          <div className="row">
            <div className="col-12 mb-5">
              <h2 className="display-7 fw-bold text-center">Missing People List</h2>
              <hr />

              <div className="modal-header">

                <div className="modal-body ">
                  <form onSubmit={this.onSearch} className="form-inline justify-content-center">

                    <div className="form-group mx-sm-3 mb-2 mr-2">
                      <select name="city"
                        className=" btn btn-outline-dark mb-2"
                        id="dropdownMenuButton"
                        ref="selectedCity"
                        required
                      >

                        <option className="dropdown-item-light">City   </option>
                        <option className="dropdown-item-light" value="Alwar">Alwar</option>
                        <option className="dropdown-item-light" value="Udaipur">Udaipur</option>
                        <option className="dropdown-item-light" value="Jaipur">Jaipur</option>
                        <option className="dropdown-item-light" value="Jodhpur">Jodhpur</option>
                        <option className="dropdown-item-light" value="Bikaner">Bikaner</option>
                        <option className="dropdown-item-light" value="Ajmar">Ajmar</option>
                        <option className="dropdown-item-light" value="Kota">Kota</option>
                        <option className="dropdown-item-light" value="Pushkar">Pushkar</option>
                        <option className="dropdown-item-light" value="Bhiwadi">Bhiwadi</option>
                        <option className="dropdown-item-light" value="Dausa">Dausa</option>
                      </select>

                    </div> <br/>
                    <button type="submit" label="Sign up" onClick={this.onSearch} className=" btn btn-outline-primary w-25 mb-3" primary={true}>Find</button>

                  </form>


                </div>
              </div>

            </div>
          </div>
          <div className="row justify-content-left">
            {console.log("this.state.arr", this.state.arr)}
            {this.state.arr.map((m, i) => {
              return (

                <div className=" col-md-4 mb-4">
                  <div className="card h-100 text-left p-0" >
                    <div className="card-body">
                      <p className="card-title fw-bold ">Name: {m.missingPersonName}</p>
                      <p className="card-text mb-0">City: {m.city}</p>
                      <p className="card-text mb-0">Gender: {m.gender}</p>
                      <p className="card-text mb-0">Age: {m.age}</p>
                      <p className="card-text mb-0">Details: {m.missingDetails}</p>
                      <p className="card-text mb-0">informerName: {m.informerName}</p>
                      <p className="card-text mb-0">Informer Mobile: {m.informerMobile}</p>
                    </div>
                  </div>
                </div>

              )
            })

            }
          </div>
        </div>

      </div>





    );
  }
}


const mapStateToProps = (state) => {
  console.log(state.MissingPeopleReducer)
  return {
    storeReducer: state.MissingPeopleReducer
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    serachPeople: (data) => {
      console.log(data)
      dispatch(Search(data))
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(MissingPeopleList);

