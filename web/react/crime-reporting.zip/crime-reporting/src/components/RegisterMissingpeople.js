import React, { Component } from 'react'
import { Link, browserHistory } from 'react-router';
import { DBfirebase } from '../database/DBfirebase'

class ReportMissingPerson extends Component {
    constructor() {
        super();
        this.state = {
            informerName: '',
            informerMobile: '',
            city: '',
            missingDetails:'',
            missingPersonName:'',
            age:'',
            gender:'',
           
        }
        this.submit = this.submit.bind(this);
        this.inputHandler = this.inputHandler.bind(this);
    }
    inputHandler(e) {
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    submit(e) {
        e.preventDefault();
        let multipath = {};
        let missingPerson = {
            informerName: this.state.informerName,
            informerMobile: this.state.informerMobile,
            city: this.state.city,
            missingDetails: this.state.missingDetails,
            missingPersonName: this.state.missingPersonName,
            age: this.state.age,
            gender: this.state.gender,
        }
        console.log(missingPerson)
       // DBfirebase.refMissing.push({missingPerson});
        DBfirebase.ref.child('missingPeople').push(missingPerson);
        browserHistory.push('/home/missingpeopleparent/missingpeople')

    }
    render() {
        return (
            <div ><center>
                <MissingPersonForm signUpState={this.state} _inputHandler={this.inputHandler} _submit={this.submit} />
            </center>
            </div>
        );
    }
}

ReportMissingPerson.contextTypes = {
    router: React.PropTypes.object.isRequired
}


class MissingPersonForm extends React.Component {

    render() {
        
        return (
            <div >
              
            <div
             className="px-0 my-0 bg-light rounded-5 py-0"
            id="loginModal"
                tabIndex="-1"
                aria-labelledby="exampleModalLabel"
                aria-hidden="true">
            <div  >
                <div className="modal-content">
                   
                    <div className="modal-header justify-content-center">
                          <h3 className="display-7 fw-bold text-center m-3 " id="exampleModalLabel">
                           Report Missing Person
                        </h3>
                      
                    </div>

                    <div className="modal-body">    
                  
                               
                <form className="form justify-content-center mx-sm-3 m-3" onSubmit={this.props._submit} >


                <div className="form-row justify-content-center mt-2 ">
                        <div className="col-md-4 mb-3">

                            <input type="text" className="form-control" id="validationDefault03" 
                            name="missingPersonName"
                        value={this.props.signUpState.missingPersonName}
                     placeholder="Missing Person Full Name"
                        onChange={this.props._inputHandler}
                                required />
                        </div>
                        <div className="col-md-2 mb-3">

                            <input type="number" className="form-control" id="validationDefault04"
                            name="age"
                        value={this.props.signUpState.age}
                        placeholder="Missed Person Age"
                        onChange={this.props._inputHandler}
                                required />
                        </div>
                    </div>



                <select name="city"
                        className="btn btn-outline-dark col-md-2 mb-2 mr-2"
                        id="dropdownMenuButton"
                        ref="selectedCity"
                        value={this.props.signUpState.city}
                        onChange={this.props._inputHandler}
                        required
                    >

                        <option className="dropdown-item-light">City   </option>
                        <option className="dropdown-item-light" value="Alwar">Alwar</option>
                        <option className="dropdown-item-light" value="Udaipur">Udaipur</option>
                        <option className="dropdown-item-light" value="Jaipur">Jaipur</option>
                        <option className="dropdown-item-light" value="Jodhpur">Jodhpur</option>
                        <option className="dropdown-item-light" value="Bikaner">Bikaner</option>
                        <option className="dropdown-item-light" value="Ajmar">Ajmar</option>
                        <option className="dropdown-item-light" value="Kota">Kota</option>
                        <option className="dropdown-item-light" value="Pushkar">Pushkar</option>
                        <option className="dropdown-item-light" value="Bhiwadi">Bhiwadi</option>
                        <option className="dropdown-item-light" value="Dausa">Dausa</option>
                    </select>
                     <select name="gender"
                        className="btn btn-outline-dark col-md-2 mb-2 "
                        id="dropdownMenuButton"
                        value={this.props.signUpState.gender}
                        onChange={this.props._inputHandler}
                        required
                    >

                        <option className="dropdown-item-light">Gender</option>
                        <option className="dropdown-item-light" value="Male">Male</option>
                        <option className="dropdown-item-light" value="Female">Female</option>
                        
                    </select>

                <div className="form-row justify-content-center my-2 ">
                        <div className="col-md-6 mb-3">
                            <textarea className="form-control mb-2 mr-sm-2 h-100" id="validationDefault01" 
                           name="missingDetails"
                        value={this.props.signUpState.missingDetails}
                        placeholder="Missing Details"
                        onChange={this.props._inputHandler}
                        required
                            />
                        </div>
                    </div>

                    <div className="form-row justify-content-center my-2 ">
                        <div className="col-md-4 mb-3">

                            <input type="text" className="form-control" id="validationDefault03" 
                           name="informerName"
                        value={this.props.signUpState.informerName}
                     placeholder="Informer Full Name"
                        onChange={this.props._inputHandler}
                           required />
                        </div>
                        <div className="col-md-2 mb-3">

                            <input type="text" className="form-control" id="validationDefault04" 
                                 name="informerMobile"
                        value={this.props.signUpState.informerMobile}
                       placeholder="Informer Mobile"
                        onChange={this.props._inputHandler}
                                required />
                        </div>
                    </div>

                        {/* <div className="form-row justify-content-center my-5"> */}

                    <button label="Report Missed Person" className="btn btn-primary col-md-3 mb-2 " type="submit" primary={false} secondary={true} >Report Missed Person</button>
                        {/* </div> */}
                </form>
                </div> 
               
                </div>
                </div>

            </div>

</div>





        )
    }
}
// MissingPersonForm.PropTypes = {
//     _inputHandler: React.PropTypes.func.isRequired,
//     _submit: React.PropTypes.func.isRequired

// }

export default ReportMissingPerson;
