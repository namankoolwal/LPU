import React from "react"
import { Link, browserHistory } from "react-router"

export default class CrimesParent extends React.Component {


  render() {
    return (

      <div className="navbarpg">
        <nav className="navbar navbar-expand-lg navbar-light bg-light ">
          <Link className="navbar-brand fw-bold fs-5 mx-3 " to="/home/crimeparent">
            CRIME REPORTS
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">

            <ul className="navbar-nav mx-auto mb-2 mb-lg-0">
            </ul>

            <div className="buttons">
              <ul className="navbar-nav mx-5 mb-2 mb-lg-0">
                <Link to="/home/crimeparent/registercrime" className="btn btn-outline-dark ms-2" primary={false}>
                  REGISTER A CRIME</Link>

                <Link to="/home/crimeparent/crimes" className="btn btn-outline-dark ms-2" primary={false}>
                  VIEW CRIMES</Link>
              </ul>
            </div>
          </div>
        </nav>
        {this.props.children}
      </div>


    )
  }
}

