import React from "react";

const Footer = () => {
  return (
<footer className="page-footer font-small fixed-bottom bg-light">
        <div className="footer-copyright text-center py-1 ">© 2023
        </div>
      </footer>
  );
};

export default Footer;
