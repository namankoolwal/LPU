import React from "react"
import { Link } from "react-router"

export default class HeaderOuter extends React.Component {
  render() {
    return (


      <div className="navbarpg">
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark py-3 shadow-sm sticky-top ">
          {/* <div className="container-fluid"> */}
          <Link className="navbar-brand fw-bold fs-4 mx-3" to="/">
            <i class="fa fa-book" aria-hidden="true"></i> Report Crime App
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation">

            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">


            <ul className="navbar-nav mx-auto mb-2 mb-lg-0">

            </ul>


            <div className="buttons">
              <ul className="navbar-nav mx-5 mb-2 mb-lg-0">


                <Link to="crimes" className="btn btn-outline-light ms-2" primary={false}>
                  <i className="fa fa-chain me-1"></i> Crimes</Link>

                <Link to="missingpeople" className="btn btn-outline-light ms-2" primary={false}>
                  <i className="fa fa-remove me-1"></i> Missing</Link>

                <Link to="signup" className="btn btn-outline-light ms-2" primary={false}>
                  <i className="fa fa-user-plus me-1"></i> SignUp</Link>
                <Link className="btn btn-outline-light ms-2" to="login" label="Login" primary={false}>
                  <i className="fa fa-sign-in me-1"></i> Login</Link>

              </ul>
            </div>


          </div>
          {/* </div> */}
        </nav>
        {this.props.children}
      </div>

    )
  }
}

