import React, { Component } from 'react'
import { Link } from 'react-router';
import { connect } from 'react-redux'
import { DBfirebase } from '../database/DBfirebase'
import { signUp } from '../store/action/auth'

class Register extends Component {
    constructor() {
        super();
        this.state = {
            fullname: '',
            email: '',
            password: '',
            city: ''
        }
        this.submit = this.submit.bind(this);
        this.inputHandler = this.inputHandler.bind(this);
    }
    inputHandler(e) {
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    submit(e) {
        e.preventDefault();
        let multipath = {};
        let newUser = {
            fullname: this.state.fullname,
            email: this.state.email,
            password: this.state.password,
            city: this.state.city
        }

        // console.log(this.state)
        DBfirebase.customAuth(newUser).then((user) => {
            multipath[`users/${user.uid}`] = newUser;
            DBfirebase.saveMultipath(multipath)
            newUser['uid'] = this.state.uid
            this.props.signUp(this.state)
            // console.log(user.uid)
            localStorage.setItem('currentUser', user.uid);
            this.context.router.push({
                pathname: "/home/missingpeopleparent"
            })
        }).catch((error) => alert(error.message))
    }
    render() {
        return (
            <div className="px-4 my-3 bg-light rounded-3 py-2"
                id="loginModal"
                tabIndex="-1"
                aria-labelledby="exampleModalLabel"
                aria-hidden="true" >
                <div className="modal-dialog">
                    <div className="modal-content">

                       
                            <SignupComponent signUpState={this.state} _inputHandler={this.inputHandler} _submit={this.submit} />
                            <center> <Link to="/login"><div id="emailHelp" className="form-text-primary mt-2">
                                Already have an account?
                            </div></Link></center>
                            <br />

                        
                    </div>
                </div>
            </div>
        );
    }
}
Register.contextTypes = {
    router: React.PropTypes.object.isRequired
}
const mapStateToProps = (state) => {
    return {
        authReducer: state
    }
}
const mapDispatchToProps = (dispatch) => {
    return {
        signUp: (data) => {
            dispatch(signUp(data))
        }
    }
}




class SignupComponent extends React.Component {

    render() {

        return (
            <div>
                <center> <div className="modal-header">
                    <h3 className="modal-title " id="exampleModalLabel">
                        Register
                    </h3>
                </div></center>
                <div className="modal-body">

                    <form onSubmit={this.props._submit} >
                    <div className="mb-3">

                        <label htmlFor="exampleInputName1" className="form-label">
                           Full Name
                        </label>
                        <input
                            className="form-control"
                            id="exampleInputName1"
                            placeholder='Full Name'
                            name="fullname"
                            value={this.props.signUpState.fullname}
                            floatingLabelText="Full Name"
                            onChange={this.props._inputHandler}
                        />
                        </div>
                         <div className="mb-3">
                        <label htmlFor="exampleInputEmail1" className="form-label">
                            Email address
                        </label>
                        <input
                            type="email"
                            placeholder="Email"
                            name="email"
                            className="form-control"
                            id="exampleInputEmail1"
                            value={this.props.signUpState.email}
                            floatingLabelText="Email"
                            onChange={this.props._inputHandler}
                        />
                         <div id="emailHelp" className="form-text">
                                        We'll never share your email with anyone else.
                                    </div>
                        </div>

                        <div className="mb-3">

                        <label htmlFor="exampleInputPassword1" className="form-label">
                            Password
                        </label>
                        <input
                            className="form-control"
                            id="exampleInputPassword1"
                            placeholder='Password'
                            type="password"
                            name="password"
                            value={this.props.signUpState.password}
                            onChange={this.props._inputHandler}
                        />
                        </div>
                       
                            <center>
                        <select name="city"
                            className="btn btn-outline-dark mt-2 "
                            id="dropdownMenuButton"
                            data-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false"
                            value={this.props.signUpState.city}
                            required
                            onChange={this.props._inputHandler}>

                            <option className="dropdown-item-light">City   </option>
                            <option className="dropdown-item-light" value="Alwar">Alwar</option>
                            <option className="dropdown-item-light" value="Udaipur">Udaipur</option>
                            <option className="dropdown-item-light" value="Jaipur">Jaipur</option>
                            <option className="dropdown-item-light" value="Jodhpur">Jodhpur</option>
                            <option className="dropdown-item-light" value="Bikaner">Bikaner</option>
                            <option className="dropdown-item-light" value="Ajmar">Ajmar</option>
                            <option className="dropdown-item-light" value="Kota">Kota</option>
                            <option className="dropdown-item-light" value="Pushkar">Pushkar</option>
                            <option className="dropdown-item-light" value="Bhiwadi">Bhiwadi</option>
                            <option className="dropdown-item-light" value="Dausa">Dausa</option>
                        </select>
                        </center>
                    
                        
                        <center><button type="submit" label="Sign up" className="btn btn-outline-primary mt-4 w-50" primary={true}>Sign up</button></center>
                       
                    </form>
                </div>
            </div>
           
        )
    }
}
SignupComponent.PropTypes = {
    _inputHandler: React.PropTypes.func.isRequired,
    _submit: React.PropTypes.func.isRequired

}

export default connect(mapStateToProps, mapDispatchToProps)(Register);