
const InitalState = {
    complaint: [],
};

const ComplaintReducer = (state = InitalState, action) => {
    switch (action.type) {
        case "find":
            return Object.assign(state, { complaint: action.value})
    }
    return state
}

export default ComplaintReducer