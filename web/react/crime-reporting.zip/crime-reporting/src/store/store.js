import { createStore, combineReducers } from 'redux'
// import logger from 'redux-logger'

import AuthReducer from './reducer/authReducer'
import MissingPeopleReducer from './reducer/missingPeopleReducer'
import CrimeReducer from './reducer/crimeReducer'
import ComplaintReducer from './reducer/complaintReducer'

export const rootReducer = createStore(combineReducers({
        AuthReducer,
        MissingPeopleReducer,
        CrimeReducer,
        ComplaintReducer
           })
           )

export let store = rootReducer;